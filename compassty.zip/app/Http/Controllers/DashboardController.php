<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

Abstract class DashboardController extends Controller
{
    //
}
